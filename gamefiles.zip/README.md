# Galactica Online

An ultimate multiplayer RPG space adventure game.